import pandas as pd
df=pd.read_csv('matches.csv')

def preprocess():
    global df
    return df