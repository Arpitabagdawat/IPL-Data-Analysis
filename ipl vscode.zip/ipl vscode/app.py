import streamlit as st
import pandas as pd
from streamlit import columns
import preprocessor
import plotly.figure_factory as ff
import plotly.express as px
import helper
import matplotlib.pyplot as plt
import seaborn as sns
import preprocessor2
import numpy as np
import preprocessor3
import preprocessor4


df= preprocessor.preprocess()
df1=preprocessor2.preprocess()
df2=preprocessor3.preprocess()
df3=preprocessor4.preprocess()


st.sidebar.image(r"C:\Users\X-STAR\Desktop\WhatsApp Image 2025-09-02 at 22.10.52_fd5a80cd.jpg")
user_menu=st.sidebar.radio(
    'select an option',
    ('Overall Analysis','Match-Wise Analysis','Team-wise Analysis','Player-wise Analysis')
)

if user_menu=='Player-wise Analysis':
    st.header('Player-wise Analysis')
    foreign_players_age = df[df['Player_Type'] == 'Overseas']['Age']
    indian_players_age = df[df['Player_Type'] == 'Indian']['Age']
    fig1 = ff.create_distplot([df['Age'], indian_players_age, foreign_players_age],
                              group_labels=["Age", 'indian_players_age', 'foreign_players_age'], show_hist=False)
    fig1.update_layout(xaxis_title="Age", yaxis_title="Density", width=800,
                       height=500,title='Age Distribution of IPL Players')
    st.plotly_chart(fig1)
    foreign_players = df[df['Country'] != 'India']['Country'].value_counts().head(5)

    country_df = foreign_players.reset_index()
    country_df.columns = ["Country", "Count"]
    fig2 = px.pie(country_df, names='Country', values='Count',title='Top 5 Overseas Player Supplying Countries')
    st.plotly_chart(fig2)

    st.subheader('Top 10 All-Time Best IPL Batsmen (Balanced Performance Index)')
    top_10 = df3.sort_values(by='total_runs', ascending=False).head(10)
    top10_average = df3[df3['out'] > 10].sort_values(by='average', ascending=False).head(10)
    top10_strikerate = df3[df3['total_runs'] > 500].sort_values(by="strikerate", ascending=False).head(10)
    df3["score"] = (
            (df3["total_runs"] / df3["total_runs"].max()) * 0.4 +
            (df3["average"] / df3["average"].max()) * 0.3 +
            (df3["strikerate"] / df3["strikerate"].max()) * 0.3
    )
    top10_balanced = df3.sort_values(by="score", ascending=False).head(10)
    top10=top10_balanced.drop(columns=['total_runs','out','numberofballs','average','strikerate'])
    st.dataframe(top10)

    st.subheader("Right vs Left Hand Batsmen")
    fig,ax=plt.subplots(figsize=(7,7))
    batting_counts = df['Batting_Hand'].value_counts()
    plt.bar(batting_counts.index, batting_counts.values)
    plt.title("Right vs Left Hand Batsmen")
    plt.xlabel("Batting Hand")
    plt.ylabel("Count")
    fig.set_size_inches(5, 3)
    st.pyplot(fig)

    st.subheader('Batting Hand × Bowling Skill Heatmap')
    bat_bowl = pd.crosstab(df["Batting_Hand"], df["Bowling_Skill"])
    fig,ax=plt.subplots(figsize=(7,7))
    ax=sns.heatmap(bat_bowl, annot=True, fmt="d", cmap="Blues")
    plt.title("Batting Hand × Bowling Skill Heatmap")
    st.pyplot(fig)


if user_menu=='Team-wise Analysis':
    st.header('Team-wise Analysis')
    st.subheader('IPL Team Performance Summary')
    team_stats=helper.team_analysis(df1)
    st.dataframe(team_stats)
    matches_played = df1.groupby(['Season', 'team1']).size() + df1.groupby(['Season', 'team2']).size()
    matches_played = matches_played.reset_index(name='matches_played')
    matches_won = df1.groupby(['Season', 'winner']).size().reset_index(name='wins')
    team_stats = matches_played.merge(matches_won, left_on=['Season', 'team1'], right_on=['Season', 'winner'],how='left')
    team_stats['wins'] = team_stats['wins'].fillna(0)
    team_stats['win_percentage'] = (team_stats['wins'] / team_stats['matches_played']) * 100

    st.subheader('Team Win % Trend Across Seasons')
    teams=helper.return_team_list(df2)
    selected_teams=st.selectbox("select team",teams)
    subset = helper.filter_team(df2,team_stats,selected_teams)
    # Line plot using Plotly
    fig3 = px.line(
        subset,
        x="Season",
        y="win_percentage",
        color="team1",  # Different line for each team
        markers=True,  # Show points on the line
    )

    # Update axis labels
    fig3.update_layout(
        xaxis_title="Season",
        yaxis_title="Win %",
        legend_title="Team"
    )
    st.plotly_chart(fig3)

    st.subheader("Team-Wise Wins Across IPL Seasons")
    team_wins = df1.groupby(['Season', 'winner']).size().reset_index(name='wins')

    # Pivot to create Team vs Season table
    pivot_df = team_wins.pivot(index='winner', columns='Season', values='wins').fillna(0)
    fig,ax=plt.subplots(figsize=(10, 7))
    ax=sns.heatmap(pivot_df, annot=True, fmt=".0f", cmap="YlGnBu", linewidths=0.5)

    plt.title("Team vs Season Wins Heatmap", fontsize=14)
    plt.xlabel("Season")
    plt.ylabel("Team")
    st.pyplot(fig)

    st.subheader("Best and Worst IPL Seasons by Team (Wins Comparison")
    best_seasons = pivot_df.idxmax(axis=1)  # season with max wins per team
    worst_seasons = pivot_df.idxmin(axis=1)  # season with min wins per team

    results = pd.DataFrame({
        "Best_Season": best_seasons,
        "Best_Wins": pivot_df.max(axis=1),
        "Worst_Season": worst_seasons,
        "Worst_Wins": pivot_df.min(axis=1)
    })
    st.dataframe(results)

if user_menu=='Overall Analysis':
    st.header('Overall Analysis')
    total_season = df1['Season'].nunique()
    total_venue = df1['venue'].nunique()
    total_city = df1['city'].nunique()
    total_players = df['Player_Name'].nunique()
    total_teams = df2['team1'].nunique()
    col1,col2,col3=st.columns(3)
    with col1:
        st.subheader('Seasons')
        st.title(total_season)
    with col2:
        st.subheader('Teams')
        st.title(total_teams)
    with col3:
        st.subheader('Players')
        st.title(total_players)
    col4, col5 ,col6= st.columns(3)
    with col4:
        st.subheader('City')
        st.title(total_city)
    with col5:
        st.subheader('Venue')
        st.title(total_venue)
    match_per_season = df1.groupby('Season').size()
    match_per_seasons = match_per_season.reset_index()
    match_per_seasons.columns = ['season', 'matches']
    fig = px.line(match_per_seasons, x="season", y="matches", width=800, height=500,title='Matches Over Years')
    st.plotly_chart(fig)

    st.subheader("Matches Hosted by Cities")
    city_match = df1['city'].value_counts().head(10)
    fig_city, ax = plt.subplots(figsize=(8, 6))
    ax.bar(city_match.index, city_match.values, color=sns.color_palette("Set3"))
    plt.xticks(rotation=45)
    st.pyplot(fig_city)

    st.subheader("Final Winners Over Years")
    final_winners = df1.dropna(subset=["winner"]).drop_duplicates("Season", keep="last")
    fig_winners, ax = plt.subplots(figsize=(10, 6))
    ax.bar(final_winners["Season"], final_winners["winner"], color="seagreen")
    plt.xticks(rotation=45)
    st.pyplot(fig_winners)

    st.subheader("Top Players of the Match Winners")
    top_players = df1['player_of_match'].value_counts().head(10)
    fig_player, ax = plt.subplots(figsize=(8, 6))
    ax.bar(top_players.index, top_players.values, color="purple")
    plt.xticks(rotation=45)
    st.pyplot(fig_player)

if user_menu=='Match-Wise Analysis':
    st.header('Match-Wise Analysis')
    df1['toss_win_match'] = (df1['toss_winner'] == df1['winner'])
    counts = df1['toss_win_match'].value_counts()
    fig4, ax = plt.subplots(figsize=(7,7))
    ax.bar(counts.index, counts.values, width=0.4,color=['skyblue', 'salmon'])
    ax.set_xlabel("Toss Winner = Match Winner")
    plt.xticks([0, 1], ['No', 'Yes'])
    plt.title('Did Toss Winner Win the Match?')
    fig4.set_size_inches(5, 3)
    ax.set_ylabel("Number of Matches")
    st.pyplot(fig4)

    runs_wins = (df1['win_by_runs'] > 0).sum()
    wickets_wins = (df1['win_by_wickets'] > 0).sum()
    wins_counts = {"Runs": runs_wins, "Wickets": wickets_wins}
    st.subheader("Wins by Runs vs Wickets")
    fig6, ax = plt.subplots()
    ax.pie(wins_counts.values(), labels=wins_counts.keys(),autopct='%1.1f%%',startangle=90,textprops={'fontsize': 6})
    fig6 = plt.gcf()
    fig6.set_size_inches(2, 2)
    st.pyplot(fig6)

    st.subheader('Largest Wins in IPL (By Runs & By Wickets)')
    highest_win_runs = df1.loc[df1['win_by_runs'].idxmax()]
    highest_win_wickets = df1.loc[df1['win_by_wickets'].idxmax()]
    max_run_win = df1.loc[df1['win_by_runs'].idxmax()]
    max_wicket_win = df1.loc[df1['win_by_wickets'].idxmax()]
    record_victories = pd.DataFrame({
     "Type": ["Largest Win by Runs", "Largest Win by Wickets"],
       "Winner": [max_run_win['winner'], max_wicket_win['winner']],
        "Opponent": [
           max_run_win['team1'] if max_run_win['winner'] != max_run_win['team1'] else max_run_win['team2'],
          max_wicket_win['team1'] if max_wicket_win['winner'] != max_wicket_win['team1'] else max_wicket_win['team2']
        ],
        "Margin": [f"{max_run_win['win_by_runs']} Runs", f"{max_wicket_win['win_by_wickets']} Wickets"],
        "Season": [max_run_win['Season'], max_wicket_win['Season']]
    })

    st.dataframe(record_victories)

    decision_stats = df1.groupby('toss_decision').apply(
        lambda x: (x['toss_winner'] == x['winner']).mean() * 100).reset_index(name='win_percentage')
    st.subheader('Bat-Winner vs Field-Winner')
    fig5, ax1=plt.subplots(figsize=(7,7))
    ax1.bar(decision_stats['toss_decision'],decision_stats['win_percentage'],width=0.4,color=['skyblue' ,'pink'])
    plt.title("Win % when choosing Bat vs Field")
    plt.ylabel("Win %")
    fig5.set_size_inches(5, 3)
    st.pyplot(fig5)

    st.subheader('Top Venue')
    city_count = df1['venue'].value_counts().head(10)
    fig,ax=plt.subplots(figsize=(7,7))
    ax.barh(city_count.index,city_count.values)
    plt.title("Top Venue by Number of Matches")
    plt.xlabel("Matches")
    fig.set_size_inches(5, 3)
    plt.gca().invert_yaxis()
    st.pyplot(fig)