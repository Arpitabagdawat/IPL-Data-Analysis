import pandas as pd
df=pd.read_csv('teams.csv')

def preprocess():
    global df
    return df