import pandas as pd
df=pd.read_csv('most_runs_average_strikerate.csv')

def preprocess():
    global df
    return df