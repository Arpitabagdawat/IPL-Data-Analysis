import pandas as pd
def team_analysis(df):
    matches_played = pd.concat([
        df['team1'],
        df['team2']
    ]).value_counts().reset_index()

    matches_played.columns = ['team', 'total_matches']

    matches_won = df['winner'].value_counts().reset_index()
    matches_won.columns = ['team', 'wins']
    # Merge matches and wins
    team_stats = matches_played.merge(matches_won, on='team', how='left').fillna(0)

    # Losses = Matches Played - Wins
    team_stats['losses'] = team_stats['total_matches'] - team_stats['wins']

    # Win Percentage
    team_stats['win_percentage'] = (team_stats['wins'] / team_stats['total_matches']) * 100

    team_season_stats = df.groupby(['Season', 'winner']).size().reset_index(name='wins')
    team_season_stats['points'] = team_season_stats['wins'] * 2
    consistency = team_season_stats.groupby('winner')['points'].mean().reset_index()
    consistency.columns = ['team', 'avg_points_per_season']
    team_stats = team_stats.merge(consistency, on='team', how='left')
    return team_stats


def  return_team_list(df):
    total_teams = df['team1'].unique().tolist()
    total_teams.insert(0, 'Overall')
    return total_teams


def filter_team(df,team_stats,team):
    if team != 'Overall':
         subset=team_stats[team_stats['team1']==team]
         return subset
    return team_stats[team_stats['team1'].isin(df['team1'].unique().tolist())]

def team_analysis(df):
    matches_played = pd.concat([
        df['team1'],
        df['team2']
    ]).value_counts().reset_index()

    matches_played.columns = ['team', 'total_matches']

    matches_won = df['winner'].value_counts().reset_index()
    matches_won.columns = ['team', 'wins']
    # Merge matches and wins
    team_stats = matches_played.merge(matches_won, on='team', how='left').fillna(0)

    # Losses = Matches Played - Wins  
    team_stats['losses'] = team_stats['total_matches'] - team_stats['wins']

    # Win Percentage  
    team_stats['win_percentage'] = (team_stats['wins'] / team_stats['total_matches']) * 100

    team_season_stats = df.groupby(['Season', 'winner']).size().reset_index(name='wins')
    team_season_stats['points'] = team_season_stats['wins'] * 2
    consistency = team_season_stats.groupby('winner')['points'].mean().reset_index()
    consistency.columns = ['team', 'avg_points_per_season']
    team_stats = team_stats.merge(consistency, on='team', how='left')
    return team_stats


def  return_team_list(df):
    total_teams = df['team1'].unique().tolist()
    total_teams.insert(0, 'Overall')
    return total_teams


def filter_team(df,team_stats,team):
    if team != 'Overall':
         subset=team_stats[team_stats['team1']==team]
         return subset
    return team_stats[team_stats['team1'].isin(df['team1'].unique().tolist())]