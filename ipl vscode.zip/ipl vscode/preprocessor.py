import pandas as pd
df=pd.read_excel('Players.xlsx')


def preprocess():
    global df
    df['Age'] = (pd.to_datetime("today") - df['DOB']).dt.days // 365
    df['Age'].fillna(df['Age'].median(), inplace=True)
    df['Batting_Hand'] = df['Batting_Hand'].str.strip().str.title()
    df['Batting_Hand'].fillna("Unknown", inplace=True)
    df['Bowling_Skill'].fillna("No Bowling", inplace=True)
    df['Country'].fillna("Unknown", inplace=True)
    df['Player_Type'] = df['Country'].apply(lambda x: 'Indian' if x == 'India' else 'Overseas')
    return df